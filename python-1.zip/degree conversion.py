temperature_in_celcius=int(input())
temperature_in_celcius=(temperature_in_celcius*9/5)+32
print("Temperature_in_farenheit: "+str(temperature_in_celcius)+" "+"F")

temperature_in_farenheit=int(input())
temperature_in_farenheit=(temperature_in_farenheit-32)*5/9
print("Temperature_in_celcius: "+str(temperature_in_farenheit)+" "+"C")

Heigth_in_cm=int(input())
Height_in_cm=(Heigth_in_cm)*0.0328084
print("Height_in_Feet: "+str(Height_in_cm))